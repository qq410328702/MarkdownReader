Markdown Reader 便携版安装包
================================

安装方法:
1. 右键点击 install.cmd
2. 选择"以管理员身份运行"
3. 按照提示完成安装

功能:
- 自动关联 .md, .markdown, .mdown 文件
- 创建开始菜单快捷方�?

卸载方法:
- 通过 Windows 设置 > 应用 > 已安装的应用 > Markdown Reader > 卸载

版本: 1.0.0
